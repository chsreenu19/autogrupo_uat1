<script>
(function($) {
    "use strict";
	

    $('#custom_fields_items').find('.col-md-3,.col-md-6').hide();
	$("#custom_fields_items").find('.col-md-3:first').show();
	
	$("body").on("blur",'input[name="custom_fields[items][1]"]',function(){
		var vinvalue = $(this).val();
		
		//$(this).focus()
		//alert($('#options_vvinnumber').val());
		
			//alert($(this).val());
			/*$("#options_vmodel").val('');
			$("#options_bodytype").val('');
			$("#options_transmission").val('');
			$("#options_fueltype").val('');
			$("#options_engine").val('');
			$("#options_vehicleyear").val('');
			$("#options_enginesize").val('');
			$("#options_seats").val('');
			$("#options_mileage").val('');
			$('#options_vcatetory').val('');
			$('#options_exteriorcolor').val('');
			$('#options_interiorcolor').val('');
			$('#options_warranty').html('');
			$('#options_mechanical').html('');
			CKEDITOR.instances['options_mechanical'].setData('');
			CKEDITOR.instances['options_vexterior'].setData('');;
			CKEDITOR.instances['options_vinterior'].setData('');;
			CKEDITOR.instances['options_ventertainment'].setData('');;
			CKEDITOR.instances['options_vsecurity'].setData('');*/
		
		if($(this).val()!=''){
        $.ajax({
            url: '<?php echo base_url() ?>/admin/warehouse/vincheck?vin='+$(this).val(),
            type: "GET",
            dataType: "json",
            success: function(result)
            {
				//debugger;
				console.log(result)
				if(result.spec.success==true){
				
				
				$('input[name="custom_fields[items][2]"]').val(result.spec.attributes.Make);
				
				$('input[name="custom_fields[items][3]"]').val(result.spec.attributes.Model);
				//
				$('input[name="custom_fields[items][11]"]').val(result.spec.attributes['Vehicle Type']);
				$('input[name="custom_fields[items][9]"]').val(result.spec.attributes['Transmission Type']);
				$('input[name="custom_fields[items][10]"]').val(result.spec.attributes['Fuel Type']);
				$('input[name="custom_fields[items][6]"]').val(result.spec.attributes.Engine);
				$('input[name="custom_fields[items][5]"]').val(result.spec.attributes.Year);
				$('input[name="custom_fields[items][7]"]').val(result.spec.attributes['Engine Size']);
				$('input[name="custom_fields[items][15]"]').val(result.spec.attributes['Standard Seating']);
				$('input[name="custom_fields[items][8]"]').val(result.spec.attributes['City Mileage']);
				$('input[name="custom_fields[items][4]"]').val(result.spec.attributes['Vehicle Category']);
				$('input[name="custom_fields[items][14]"]').val(result.spec.interiorcolor);
				$('input[name="custom_fields[items][13]"]').val(result.spec.exteriorcolor);
				$('input[name="custom_fields[items][18]"]').html(result.spec.warranty);
				$('input[name="custom_fields[items][16]"]').val(result.spec.attributes.Doors);
				
				$('custom_fields[items][24]').html(result.spec['vexterior']);
				
				tinymce.get('custom_fields[items][24]').setContent(result.spec['vexterior']);
				tinymce.get('custom_fields[items][25]').setContent(result.spec['vinteriors']);
				tinymce.get('custom_fields[items][26]').setContent(result.spec['vsafety']);
				tinymce.get('custom_fields[items][27]').setContent(result.spec['mehcanical']);
				tinymce.get('custom_fields[items][28]').setContent(result.spec['ventertainment']);
				
				
				//general info
				$('input[name="commodity_code"]').val(vinvalue +'  '+ result.spec.attributes.Make + ' ' +result.spec.attributes.Model);
				$('input[name="description"]').val(result.spec.attributes.Make + ' ' +result.spec.attributes.Model);
				$('input[name="commodity_barcode"]').val(vinvalue);
				$('input[name="sku_code"]').val(vinvalue);
				$('input[name="sku_name"]').val(result.spec.attributes.Make + ' ' +result.spec.attributes.Model);
				
				var vechicle_description = 'VIN : ' + vinvalue + '<br>';
					vechicle_description += 'Make : ' + result.spec.attributes.Make + '<br>';
					vechicle_description += 'Model : ' + result.spec.attributes.Model + '<br>';
					vechicle_description += 'Transmission : ' + result.spec.attributes['Transmission Type'] + '<br>';
					vechicle_description += 'Engine : ' + result.spec.attributes.Engine + '<br>';
					vechicle_description += 'Fuel : ' + result.spec.attributes['Fuel Type'] + '<br>';
					//vechicle_description += 'Color : ' + + '<br>';
				tinymce.get('long_description').setContent(vechicle_description);
				
				console.log(vechicle_description);
				
				$('#custom_fields_items').find('.col-md-3,.col-md-6').fadeIn();
				
				$("iframe").each(function () {
					//Using closures to capture each one
					var iframe = $(this);
					iframe.on("load", function () { //Make sure it is fully loaded
						iframe.contents().click(function (event) {
							console.log('click');
							iframe.trigger("click");
						});
					});

					iframe.click(function () {
						//Handle what you need it to do
					});
				});
				
				}else{
					alert('No results found for the VIN number '+ $(this).val())
					$('#custom_fields_items').find('.col-md-3,.col-md-6').fadeIn();
				}
				
            },
            error: function(xhr, ajaxOptions, thrownError)
            {
                console.log(xhr.status);
                console.log(thrownError);
            }
        });
		
	}
    });
	
	
   
})(jQuery);

</script>