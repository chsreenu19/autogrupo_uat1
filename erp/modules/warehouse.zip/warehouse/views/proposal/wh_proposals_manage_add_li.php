<li class="">
  <a href="#" data-cview="proposals_processing" onclick="dt_custom_view('proposals_<?php echo 'processing'; ?>','.table-proposals','proposals_<?php echo 'processing'; ?>'); return false;">
  <?php echo _l('processing'); ?>
  </a>
</li>